import { reactive } from "vue";

const state = reactive({
  cant:0
});

const methods = {
  
};

const getters = {
  
};

export default {
  state,
  methods,
  getters,
};
