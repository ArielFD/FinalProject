<template>
  <div class="text-primary">
    <div class="row">
      <div class="col-4 q-pa-md">
        <h5>Mision</h5>
        Proporcionar a la sociedad, servicios y productos relacionados con el
        hogar.
      </div>
      <div class="col-8 q-pa-md">
        <h5>Vision</h5>
        Somos una organización reconocida por la calidad y el alto valor
        agregado de los servicios y productos que se ofertan. Contamos con una
        red de instalaciones distribuidas por todo el país y un capital humano
        altamente competente, cuya profesionalidad garantiza la máxima
        satisfacción de nuestros clientes.
      </div>
    </div>
    <q-separator />
    <h4 class="text-center">Departamentos</h4>
    <div class="row">
      <div class="col-4 q-pa-md">
        <h5>Departamento Financiero</h5>
        <b>Directivo en Jefe:</b> David Crespo <br>
        David@gmail.com
      </div>
      <div class="col-4 q-pa-md">
        <h5>Departamento de Recursos Humanos</h5>
        <b>Directivo en Jefe:</b> Ariel Bravo<br>
        Ariel@gmail.com
      </div>
      <div class="col-4 q-pa-md">
        <h5>Departamento Comercial</h5>
        <b>Directivo en Jefe:</b> Lidia Laura<br>
        Lidia@gmail.com
      </div>
      <div class="col-4 q-pa-md">
        <h5>Departamento de Compras</h5>
        <b>Directivo en Jefe:</b> Lazara<br>
        Lazara@gmail.com
      </div>
      <div class="col-4 q-pa-md">
        <h5>Departamento de Logística y Operaciones</h5>
        <b>Directivo en Jefe:</b> Jorge<br>
        Jorge@gmail.com
      </div>
      <div class="col-4 q-pa-md">
        <h5>Departamento de Control de Gestión</h5>
        <b>Directivo en Jefe:</b> Osniel<br>
        Osniel@gmail.com
      </div>
      <div class="col-4 q-pa-md">
        <h5>Dirección General</h5>
        <b>Directivo en Jefe:</b> Ariel Ferrera Diaz<br>
        arielferrera1992@gmail.com
      </div>
    </div>
    <q-separator />
    <div>
        <h3 class="text-center">De nuestro servicio</h3>
        <q-avatar>
          <q-icon name="location_on" />
        </q-avatar>
        Reconocimiento por la calidad al trabajo 2019
        <br />
        <q-avatar>
          <q-icon name="settings_phone" />
        </q-avatar>
        Brindamos servicion todos los dias de la semana las 24 horas
        <br />
        <q-avatar>
          <q-icon name="email" />
        </q-avatar>
        Servicio de mensajeria
        <br />
        <q-avatar>
          <q-icon name="public" />
        </q-avatar>
        Posibilidad de pago por transferencia
      </div>
  </div>
</template>