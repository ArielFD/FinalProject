<template>
  <div class="text-primary">
    <h3 class="text-center">Marco Legal</h3>
    <h6 class="text-center">
      <a href="https://www.gacetaoficial.gob.cu/es" target="_blank" class="text-primary">GACETA OFICIAL DE CUBA</a>
    </h6>
    <div class="row">
      <div class="col-4 q-pa-md">
        <h5>Resolucion 98</h5>
        El presente Reglamento tiene por objeto establecer las disposiciones que
        rigen el empleo de redes de telecomunicaciones inalámbricas de alta
        velocidad en las bandas de frecuencias de 2400 MHz a 2483.5 MHz, 5150
        MHz a 5350 MHz, 5470 MHz a 5725 MHz y 5725 MHz a 5850 MHz en la
        República de Cuba.
      </div>
      <div class="col-4 q-pa-md">
        <h5>Resolucion 99</h5>
        El objeto del presente Reglamento es el establecimiento de las normas
        para la organización, funcionamiento y expedición de las licencias de
        operación de las redes privadas de datos
      </div>
      <div class="col-4 q-pa-md">
        <h5>Resolucion 141</h5>
        Establecer las indicaciones generales para la migración hacia
        plataformas de código abierto y la generalización de programas y
        aplicaciones informáticas de producción nacional en los sistemas
        operativos de los nodos tecnológicos, servidores o centros de datos
        privados que soportan los sistemas informáticos, así como las
        computadoras personales de escritorio y portátiles , que estén todos
        conectados a Internet.
      </div>
      <div class="col-4 q-pa-md">
        <h5>Resolucion 129</h5>
        La presente metodología tiene por objeto determinar las acciones a
        realizar en una entidad durante el diseño, la implementación y posterior
        operación de un Sistema de Gestión de la Seguridad Informática, en lo
        adelante SGSI, compuesta por dos partes,la primera se dedica al SGSI y
        la segunda a la estructura y contenido del Plan de Seguridad
        Informática.
      </div>
      <div class="col-4 q-pa-md">
        <h5>Resolucion 36</h5>
        La medidas correctivas que se apliquen a los clientes que incumplan con
        los deberes establecidos por esta entidad para esta y que son divulgados
        en la cartelera de servicios de cada entidad o cometan otros actos que
        atenten contra el funcionamiento y la disciplina de las instalaciones de
        servicio
      </div>
    </div>
  </div>
</template>